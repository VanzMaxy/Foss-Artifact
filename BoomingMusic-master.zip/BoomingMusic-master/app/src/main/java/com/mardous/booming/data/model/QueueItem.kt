package com.mardous.booming.data.model

import androidx.media3.common.MediaItem

class QueueItem(val mediaItem: MediaItem, val indexInTimeline: Int)