package com.theveloper.pixelplay.data.preferences

object CarouselStyle {
    const val NO_PEEK = "no_peek"
    const val ONE_PEEK = "one_peek"
    const val TWO_PEEK = "two_peek"
}