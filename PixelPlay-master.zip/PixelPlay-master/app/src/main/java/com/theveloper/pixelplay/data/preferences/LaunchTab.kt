package com.theveloper.pixelplay.data.preferences

object LaunchTab {
    const val HOME = "Home"
    const val SEARCH = "Search"
    const val LIBRARY = "Library"
}