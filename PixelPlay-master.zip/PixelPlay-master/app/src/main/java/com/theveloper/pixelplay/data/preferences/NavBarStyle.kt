package com.theveloper.pixelplay.data.preferences

object NavBarStyle {
    const val DEFAULT = "default"
    const val FULL_WIDTH = "full_width"
}
